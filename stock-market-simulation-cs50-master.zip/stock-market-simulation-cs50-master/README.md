#Stock Market Simulation - CS50
This is a stock market simulation website that I worked on as part of a online CS course that I 
took called CS50: Introduction to Computer Science. I highly recommend it. You can find it 
on edX at the following link: https://www.edx.org/course/introduction-computer-science-harvardx-cs50x

The goal of this project was to use the fundamental concepts of MVC (Model-View-Controller) to create a 
website to buy and sell stock in real time with data from Yahoo Finance. I used HTML, CSS, JavaScript, php,
Python (in another version of the site), and MySQL to create this website. 

I've really wanted to create a stock market simulation for a long time, and this project was just an introduction
to what I could make. I used a lot of source code that was supplied by the couse and I am planning sometime in 
the near future to expand this project so I can make it truly my own with my own new features. 

Feel free to look at the code, and make sure to check out the great course in the link above. 